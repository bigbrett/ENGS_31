system "vsim -gui -do go.tcl";

